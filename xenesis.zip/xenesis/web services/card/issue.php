<html>
<head>
	<title>login</title>
	<link href="issue.css" rel="stylesheet">
		
</head>
<body>

	</div>
			<p style="font-size:400%; color:black;padding-top: 0;font-family:Bahnschrift SemiBold Condensed;height:80px;width:100%;color: white;">XENESIS</p>
			<progress style="top:90px;position: absolute;"></progress>
		
<div class="box">
	<h2 style="color:#03a9f4">Issue Book</h2>
			
		<form action="card.php" method="POST">
				<div class="inputbox">
			    
					  <label>Student Id</label>
					  <input type="text" name="user" id="" placeholder="Student Id" class="Username">
			    </div>
			    <div class="password">

					  <label><abbr title="17 digit required">Password</abbr></label>
					  <input type="password" name="eno" id="" placeholder="password" class="pass">
			    </div>
			    
			    
					 

			  <center><button type="submit" name='s'>Issue Book</button></center>
		</form>

<?php
error_reporting(0);
if(isset($_POST['s']))
	{
		$user=$_POST['user'];
	$pass=$_POST['eno'];
	//$eno=$_POST['eno'];
	//$mail=$_POST['mail'];
	//$con=$_POST['con'];


}
?>

<?php
$hostname="localhost";
$username="root";
$password="";
$dbName="library";
$flag=0;
//////////////////////////////////////////////////////////////////////////////////
//detabase connection
$db=mysqli_connect($hostname, $username, $password, $dbName);
//detabase selection

$st=mysqli_select_db($db,$dbName);
//////////////////////////////////////////////////////////////////////////////////

if($db)
{echo"<br>";
if($st)
{//echo"Database connected <br>";
$flag=1;
}
else
 echo"Database connected <br>";
}
else
echo"MySql not connected<br>";

///////////////////////////////////////////detabase query//////////////////////////


if($flag==1)
{ // $drop_sql="DROP DATABASE ".$dbName;
	//if(mysqli_query($db,$drop_sql))
	//	echo "<br>database droped<br>";
	//else
	//	echo"<br>database not droped<br>";
$insert = " INSERT INTO card VALUES ( '".$user ."','suryansh trivedi','Let us C','". $eno."',NULL,NULL,NULL);";   
//echo $insert;
$tr=mysqli_query($db,$insert);
//echo $tr;
if($tr==1)
echo "";
			
//echo "Record Subbmited<br>";

}
else
echo"Access denied<br>";


?>





</div>

