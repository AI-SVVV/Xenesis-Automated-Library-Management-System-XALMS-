<html>
<head>	<title>reservation</title>

	<link href="card.css" rel="stylesheet">
		<ul>
		<li><a href="card_home.html">Log Out</a></li>
		
	</ul>
</head>
<body>
	</div>
			<p style="font-size:400%; color:black;padding-top: 0;font-family:Bahnschrift SemiBold Condensed;height:80px;width:100%;color: white;">XENESIS</p><progress style="top:90px;position: absolute;"></progress>

	



	<div style="color: #03a9f4; top: 20%;left: 40%;position: absolute;">
	<center><?php
$username = "root";
$password = "";
$database = "library";
$mysqli = new mysqli("localhost", $username, $password, $database);
 
$query = "SELECT * FROM card WHERE studentid =1";
//echo "<b> <center></center> </b> <br> <br>";

 
if ($result = $mysqli->query($query)) {
 
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["studentid"];
        $field2name = $row["studentname"];
        $field3name = $row["bookid"];
        $field4name = $row["bookname"];
        $field5name = $row["issuedate"];
        $field6name = $row["subbmitdate"];
        $field7name = $row["fine"];
       // echo"<center>";
        echo"<div style='left: 5%;position: absolute;'> <pre>"; 
        echo"<h1>  Student Id     :".$field1name ."</h1><br>";
        echo"<h1>    Student Name   :".$field2name ."</h1><br>";
        echo"<h1>   Book Id        :". $field3name ."</h1><br>";
        echo"<h1>         Book Name      :".$field4name ."</h1><br>";
        echo"<h1>                    Issue Date     :".$field5name ."</h1><br>";
        echo"<h1> Return Date    :". $field6name ."</h1><br>";
        echo"<h1> Fine           :". $field7name ."</h1><br>";     
      echo"</pre> </div>";
    //echo"</center>";
        //echo"". $field2name ."&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp";
 
        //echo "<br><br>";
  
    }
    echo "</div>";
 
/*freeresultset*/
$result->free();
}
?>
<div clas=booknow  style=" height:90%;width:50%;top:17%; left:55%; position: absolute;opacity:1.0;background: black;border:none;border-radius:10px;opacity: 0.4;background-color:black;font-size: 200%;">
</div>
                 <a href="#"><button style="background: url(student.png); height: 200px;width: 200px;top:20%; left:3%;position: absolute;opacity:1.0;"></button></a>
          
      

</center>
</div>
</body>
</html>