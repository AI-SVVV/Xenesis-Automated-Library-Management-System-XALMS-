<html>
<head>	<title>reservation</title>

	<link href="reservation.css" rel="stylesheet">
		<ul>
		<li><a href="contect.html">Contact</a></li>
		<li><a href="form.php">SignUp</a></li>
		<li><a href="reservation.php">Books</a></li>
		<li><a href="about.html">About</a>
			<ul>
			<li><a href="services.html">Announcement</a></li>
			<li><a href="events.html">Presentation</a></li>
			<li><a href="restaurents.html">Help</a></li>
			</ul>
		</li>
		<li><a href="home.html">Home</a></li>
	</ul>
</head>
<body>
	</div>
			<p style="font-size:400%; color:black;padding-top: 0;font-family:Bahnschrift SemiBold Condensed;height:80px;width:100%;color: white;">XENESIS</p><progress style="top:90px;position: absolute;"></progress>
			
		
	<div class="search_bg" style="top:75%;left:25%;position:absolute;background:black;height:15%;width:60%;">
		</div>
	<div class="search_box">
		<input  type="text" name="" placeholder="Search">
		<button>Search</button>
	</div>	
	


<div style="font-size: 100%; color:black ;position:absolute;top:168%;width:100%;height:40%;width:100%;">
		<hr  width="100%" >
		<p >	&nbsp &nbsp	&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp copyright &copy SKT groups.pvt.ltd.</p>
	</div>
	<div style="color: #03a9f4;">
	<center><?php
$username = "root";
$password = "";
$database = "library";
$mysqli = new mysqli("localhost", $username, $password, $database);
 
$query = "SELECT * FROM bookdetails WHERE subject LIKE 'electrical'";
echo "<b> <center>Database Output</center> </b> <br> <br>";
echo '<table border="0" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td style="color:#03a9f4;"> <font face="Arial">Id</font> </td> 
          <td style="color:#03a9f4;"> <font face="Arial">Book ID</font> </td> 
          <td style="color:#03a9f4;"> <font face="Arial">Book Name</font> </td> 
          <td style="color:#03a9f4;"> <font face="Arial">Authorname</font> </td> 
          <td style="color:#03a9f4;"> <font face="Arial">Avalability</font> </td> 
          <td style="color:#03a9f4;"> <font face="Arial">Subject</font> </td> 
      </tr>';
 
if ($result = $mysqli->query($query)) {
 
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["id"];
        $field2name = $row["bookid"];
        $field3name = $row["bookname"];
        $field4name = $row["authorname"];
        $field5name = $row["avalability"];
        $field6name = $row["subject"];
 
       /* echo $field1name ."&nbsp &nbsp &nbsp &nbsp";
        echo $field3name ."&nbsp &nbsp &nbsp &nbsp";
        echo $field4name ."&nbsp &nbsp &nbsp &nbsp";
        echo $field5name ."&nbsp &nbsp &nbsp &nbsp";
        echo $field2name ."&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp";
 
        echo "<br><br>";
        */
        echo "<div style='color:#03a9f4;'>";
        echo "<tr> 
                  <td style='color:#03a9f4;'>".$field1name."</td> 
                  <td style='color:#03a9f4;'>".$field2name."</td> 
                  <td style='color:#03a9f4;'>".$field3name."</td> 
                  <td style='color:#03a9f4;'>".$field4name."</td> 
                  <td style='color:#03a9f4;'>".$field5name."</td>
                  <td style='color:#03a9f4;'>".$field6name."</td> 
              </tr>";
    }
    echo "</div>";
 
/*freeresultset*/
$result->free();
}
?>
</center>
</div>
</body>
</html>